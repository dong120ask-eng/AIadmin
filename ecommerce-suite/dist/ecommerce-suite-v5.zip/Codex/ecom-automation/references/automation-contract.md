# 自动化能力与接入契约

## 当前交付状态

已实现：离线计算、任务持久化、本机同状态库排他、停止开关、店铺/动作/对象/到期授权检查、前值比较、预览、提交与重读流程、未决状态禁止自动重放。

尚未实现：七平台专用API/浏览器适配、活动资格与优惠专用校验、跨主机分布式锁、真实库存服务、资金预算原子预留、告警投递、生产级调度和真实店铺验收。活动报名、活动修改、广告计划、价格和库存写入在通用执行器中固定阻塞，接通插件本身也不能绕过。

## 任务与插件协议

config含mode(preview/execute)、stop、authorization、adapters和tasks。默认preview。授权含stores、actions、targets_by_store（按店铺的对象列表）、valid_until(含时区)。每任务含task_id、store_id、target_id、action；商品写任务还含expected_before与desired_value。

adapters映射店铺ID到可信本地执行程序的argv数组。程序会在本机运行，必须经所有者审阅，不能使用商品页或外部文本提供的命令，不把密钥写argv；从安全环境读取凭据。请求为stdin JSON：op(read/write)、store_id、action、target_id、idempotency_key及前后值。响应stdout JSON需含store_id、ok，读取含value，写入含receipt_id。stdout只输出协议，诊断日志脱敏写stderr。超时60秒；写超时标unknown，不自动重复。

读取动作：campaign_detect、product_read、metrics_read、ad_report_read。商品变更：product_title_update、product_main_image_update、product_detail_update、product_selling_points_update。主图/详情真实上传审核、资源ID转换与平台校验属于适配器职责，通用工具不负责。

本机锁要求所有任务共享同一个state路径；不能把不同状态库视为全局排他。文件锁异常退出可能残留，先核进程和平台结果后人工清理。进程崩溃留下running时按未决任务对账，不擅自删除记录重跑。保留数据库备份并限制本机访问。

## 全自动业务验收顺序

1. 核实真实店铺、官方数据来源和读取权限，对照后台结果。
2. 保存活动快照并核截止和资格；用真实商品成本跑利润与优惠情景。
3. 有授权时用一个可逆商品字段做预览/执行/回读，核审核与前端展示；素材修改核平台审核状态。
4. 为报名、预算、库存实现各自专用适配器与限额服务，测试超时已成功、不重复报名、过期授权、账号串用和并发冲突。
5. 接宿主调度与告警，进行故障恢复演练，再扩多店；最后验实际订单、退款后利润与履约。

本次测试仅证明本地门控和离线计算，不证明以上步骤已完成。没有店铺连接时，输出自动化操作包和阻塞列表，不把人工步骤写成已自动完成。


v5配置追加：stores映射店铺到tenant_id/platform；authorization.bindings必须与店铺绑定完全一致。适配请求及响应均含tenant_id/platform/store_id。旧配置不自动迁移为有效授权。
